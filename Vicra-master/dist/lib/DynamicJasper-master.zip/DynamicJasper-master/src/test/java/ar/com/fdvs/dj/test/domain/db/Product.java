package ar.com.fdvs.dj.test.domain.db;

public class Product {

}
