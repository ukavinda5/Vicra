#!/bin/bash
java -cp $M2_REPO/hsqldb/hsqldb/1.8.0.7/hsqldb-1.8.0.7.jar org.hsqldb.util.DatabaseManager
