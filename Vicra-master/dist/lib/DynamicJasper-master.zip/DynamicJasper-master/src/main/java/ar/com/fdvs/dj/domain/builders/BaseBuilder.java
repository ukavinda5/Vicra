package ar.com.fdvs.dj.domain.builders;

/**
 * Created by mamana on 28/9/2016.
 */
public class BaseBuilder<T> {
}
