package ar.com.fdvs.dj.domain.constants;

import java.io.Serializable;

public class BaseDomainConstant implements Serializable {

	private static final long serialVersionUID = 1L;

}
